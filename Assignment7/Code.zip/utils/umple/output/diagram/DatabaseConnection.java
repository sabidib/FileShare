/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.20.2.4305 modeling language!*/



// line 47 "diagram.ump"
public class DatabaseConnection
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public DatabaseConnection()
  {}

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {}

}