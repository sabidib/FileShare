
$(function() {
  $('[data-toggle="tooltip"]').tooltip();
  var controller = new Controller(location.hostname,9000);
});   



